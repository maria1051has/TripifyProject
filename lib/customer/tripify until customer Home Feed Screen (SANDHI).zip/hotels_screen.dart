import 'package:flutter/material.dart';

class HotelsScreen extends StatelessWidget {
  final String placeName;

  const HotelsScreen({super.key, required this.placeName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // ✅ White background
      appBar: AppBar(
        title: Text("Hotels in $placeName"),
        backgroundColor: const Color(0xFF008080),
      ),
      body: Center(
        child: Text(
          "Here will be the Hotels UI for $placeName",
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}